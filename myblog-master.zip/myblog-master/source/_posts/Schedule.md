---
title: Schedule
date: 2020-05-28 01:56:46
tags: 233
top: false
---
每日计划:
### jun 24
考完了期中考试。。。脑壳疼，但是！ 写作业吧

<!--more-->
### jun 23
 - [x] 今日看完577的内容 最短路径 和 随机化 ！！！
 - [x] 写作业啊写作业

### jun 13
Macbook 出了点小问题，一个键被我扣坏了，，用着有点难受。今天载windows 上装了下WSl, 基本上应该搞好了。。下周恢复努力学习！！！！周末要看577.



### Jun 04 -08
 - [x] 今天看了一天577，总算有点看懂这门课了。。。
 - [ ] 看了很久很久的 577 把作业交了，以后周二周四更新。


### Jun 03
  - [ ] 577 上课
  - [x] JAVA Zybook 30 minutes
  - [ ] SDC 整理2条命令
  - [ ] CMOS VLSI Design 看20页
  - [x] 高级 ASIC 芯片综合 看到了第四章，，还是 VLSI 有意思
  - [ ] Algorithm 第一章+第五章
  - [ ] UVM课程每日章节
今天心情不太好没做啥，，，明天加油，，，，整天都在睡觉。


### Jun 02
  - [x] 577 review and discussion
  - [x] JAVA Zybook 30 minutes
  - [x] SDC 整理2条命令
  - [x] CMOS VLSI Design 看20页
  - [ ] 高级 ASIC 芯片综合 第一章 P0-28 //太高估自己了没做看完
  - [x] Algorithm 相关章节 (太难了没看懂，，不过本来就是一周的量！)
  - [x] UVM课程每日章节


6月学习计划：
 - [ ] SDC 命令整理
 - [ ] JAVA CS400 学习
 - [ ] Algorithm CS577 算法
 - [ ] 此外还要准备面试， 主要是VLSI方向
 - [ ] 闲着无聊报了个路科的验证培训班（V1), 入门有点过于基础，Hoffman 万岁！

