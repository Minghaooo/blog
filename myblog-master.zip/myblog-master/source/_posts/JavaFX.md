---
title: JavaFX
date: 2020-06-26 23:25:47
tags: CS400
---

### GUIs in java: 
* AWT Abstract windowing toolkit. classes that create graphic components.(hard to use)
* Applets: run in web browsers.
* Swing: success
* JavaFX support desktop applications, but also web browses

### JavaFX Basics
* rich set of commonly used UI components

put classes into package application
class Main extends javafx.application.application
main() method calls launch(arg) 
launch args initializes required GUI
start 